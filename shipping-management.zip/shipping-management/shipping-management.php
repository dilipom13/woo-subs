<?php
<?php
/**
 * Plugin Name: Shipping Management
 * Plugin URI: http://yourwebsite.com/shipping-management
 * Description: Custom Shipping Management plugin for WooCommerce.This plugin adds advanced shipping management features to WooCommerce.
 * Version: 1.0
 * Author: Your Name
 * Author URI: http://yourwebsite.com
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * Tested up to: 5.8
 * WC requires at least: 3.0.0
 * WC tested up to: 5.5.0
 * Text Domain: shipping-management
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/*function shipping_management_add_settings_page() {
    add_submenu_page(
        'woocommerce',
        __('Shipping Management', 'shipping-management'),
        __('Shipping Management', 'shipping-management'),
        'manage_options',
        'shipping-management-settings',
        'shipping_management_settings_page_callback'
    );
}
add_action('admin_menu', 'shipping_management_add_settings_page');*/

function shipping_management_add_test_page() {
    add_submenu_page(
        'options-general.php',
        'Shipping Management Test',
        'Shipping Management Test',
        'manage_options',
        'shipping-management-settings-test',
        'shipping_management_settings_page_callback'
    );
}
add_action('admin_menu', 'shipping_management_add_test_page');

function shipping_management_settings_page_callback() {
    $settings = get_option('shipping_management_rules', []);
    ?>
    <div class="wrap">
        <h2><?php _e('Shipping Management Settings', 'shipping-management'); ?></h2>
        <form method="post" action="">
            <?php wp_nonce_field('shipping_management_settings_save', 'shipping_management_settings_nonce'); ?>

            <div id="shipping-rules-wrapper">
                <?php foreach ($settings as $index => $rule) : ?>
                    <div class="shipping-rule">
                        <input type="text" name="shipping_rules[<?php echo $index; ?>][weight]" placeholder="Weight" value="<?php echo esc_attr($rule['weight']); ?>">
                        <input type="text" name="shipping_rules[<?php echo $index; ?>][pin_code]" placeholder="PIN Code" value="<?php echo esc_attr($rule['pin_code']); ?>">
                        <input type="text" name="shipping_rules[<?php echo $index; ?>][price]" placeholder="Price" value="<?php echo esc_attr($rule['price']); ?>">
                        <button type="button" class="remove-rule button button-secondary">Remove</button>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="button button-primary" id="add-rule">Add Rule</button>

            <?php submit_button(); ?>
        </form>
    </div>

    <script>
        jQuery(document).ready(function($) {
            $('#add-rule').click(function() {
                var wrapper = $('#shipping-rules-wrapper');
                var newIndex = wrapper.find('.shipping-rule').length;
                wrapper.append('<div class="shipping-rule"><input type="text" name="shipping_rules[' + newIndex + '][weight]" placeholder="Weight"><input type="text" name="shipping_rules[' + newIndex + '][pin_code]" placeholder="PIN Code"><input type="text" name="shipping_rules[' + newIndex + '][price]" placeholder="Price"><button type="button" class="remove-rule button button-secondary">Remove</button></div>');
            });

            $(document).on('click', '.remove-rule', function() {
                $(this).parent('.shipping-rule').remove();
            });
        });
    </script>
    <?php
}



// This function should be called when your settings form is submitted.
function shipping_management_save_settings___() {
    check_admin_referer('shipping_management_settings_save');

    // Assume your repeater fields are named 'shipping_rules' and passed as an array.
    $shipping_rules = isset($_POST['shipping_rules']) ? $_POST['shipping_rules'] : array();

    // Sanitize and validate your input as necessary
    $sanitized_rules = array();
    foreach ($shipping_rules as $rule) {
        $sanitized_rule = array(
            'weight' => sanitize_text_field($rule['weight']),
            'pin_code' => sanitize_text_field($rule['pin_code']),
            'price' => sanitize_text_field($rule['price'])
        );
        array_push($sanitized_rules, $sanitized_rule);
    }

    update_option('shipping_management_rules', $sanitized_rules);
}


function shipping_management_register_shipping_method() {
    if ( ! class_exists( 'WC_Shipping_Management_Method' ) ) {
        class WC_Shipping_Management_Method extends WC_Shipping_Method {
            /**
             * Constructor. The instance ID is passed to this.
             */
            public function __construct( $instance_id = 0 ) {
                parent::__construct( $instance_id );

                $this->id                 = 'shipping_management'; // ID for your shipping method. Should be uunique.
                $this->instance_id        = absint( $instance_id );
                $this->method_title       = __( 'Shipping Management', 'shipping-management' ); // Title shown in admin
                $this->method_description = __( 'Custom Shipping Management for Weight and Location (PIN Code)', 'shipping-management' ); // Description shown in admin

                $this->supports = array(
                    'shipping-zones',
                    'instance-settings',
                    'instance-settings-modal',
                );

                $this->init();
            }

            /**
             * Initialize shipping method. Load the settings API.
             */
            function init() {
                // Load the settings.
                $this->init_form_fields(); // This can be left empty if you're not adding custom form fields for admin settings
                $this->init_settings(); // Load the defined settings

                // Save settings in WooCommerce > Settings > Shipping > Shipping Management
                add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
            }

            /**
             * Calculate shipping function.
             *
             * @param array $package Package information.
             */
            public function calculate_shipping( $package = array() ) {
                $rate = array(
                    'id'       => $this->get_rate_id(),
                    'label'    => $this->title,
                    'cost'     => '10.00', // Example static cost
                    'calc_tax' => 'per_item',
                );

                // Add the rate to WooCommerce
                $this->add_rate( $rate );
            }
        }
    }
}

function add_shipping_management_method( $methods ) {
    $methods['shipping_management'] = 'WC_Shipping_Management_Method';
    return $methods;
}
add_filter( 'woocommerce_shipping_methods', 'add_shipping_management_method' );


add_action('admin_init', 'shipping_management_register_settings');

function shipping_management_register_settings() {
    if (isset($_POST['shipping_management_settings_nonce']) && wp_verify_nonce($_POST['shipping_management_settings_nonce'], 'shipping_management_settings_save')) {
        shipping_management_save_settings();
    }
}

function shipping_management_save_settings() {
    // Assuming validation and sanitization are done as before
    $sanitized_rules = array();
    if (isset($_POST['shipping_rules'])) {
        foreach ($_POST['shipping_rules'] as $rule) {
            $sanitized_rules[] = array(
                'weight' => sanitize_text_field($rule['weight']),
                'pin_code' => sanitize_text_field($rule['pin_code']),
                'price' => sanitize_text_field($rule['price'])
            );
        }
    }

    update_option('shipping_management_rules', $sanitized_rules);
}
